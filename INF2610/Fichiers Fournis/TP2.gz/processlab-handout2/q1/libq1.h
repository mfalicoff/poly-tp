/*
 * Init Lab - libq1.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _LIBQ1_H
#define _LIBQ1_H

void evaluateQuestion1();

#endif