// To do

// To do
GestionnaireSaisons::~GestionnaireSaisons()
{
    // To do
}

// To do
GestionnaireSaisons& GestionnaireSaisons::operator+=(std::unique_ptr<Saison> saison)
{
    // To do
}

// To do
GestionnaireSaisons& GestionnaireSaisons::operator-=(const unsigned int numSaison)
{
    // To do
}

// To do
void GestionnaireSaisons::ajouterEpisode(const unsigned int numSaison,
                                         std::unique_ptr<Episode> episode)
{
    // To do
}

// To do
void GestionnaireSaisons::retirerEpisode(const unsigned int numSaison,
                                         const unsigned int numEpisode)
{
    // To do
}

/// To do
size_t GestionnaireSaisons::trouverIndexSaison(const unsigned int numSaison) const
{
    // To do
}

// To do
Saison* GestionnaireSaisons::getSaison(const unsigned int numSaison) const
{
    // To do
}

// To do
size_t GestionnaireSaisons::getNbSaisons() const
{
    // To do
}
