/*
 * Titre : Pixel.cpp - Travail Pratique #4 - Programmation Orient�e Objet
 * Date : 27 F�vrier 2020
 * Auteur : Nabil Dabouz
*/
#include "Pixel.h"

Pixel::Pixel() :
	rouge_(0), vert_(0), bleu_(0)
{
}

Pixel::Pixel(uint8_t rouge, uint8_t vert, uint8_t bleu) :
	rouge_(rouge), vert_(vert), bleu_(bleu)
{
}

void Pixel::operator=(const Pixel& pixel)
{
	rouge_ = pixel.rouge_;
	vert_ = pixel.vert_;
	bleu_ = pixel.bleu_;
}

void Pixel::setRouge(int rouge) {
	rouge = (rouge < (int)255) ? rouge : 255;
	rouge = (rouge > 0) ? rouge : 0;
	rouge_ = (uint8_t)rouge;
}

void Pixel::setVert(int vert) {
	vert = (vert < 255) ? vert : 255;
	vert = (vert > 0) ? vert : 0;
	vert_ = (uint8_t)vert;
}

void Pixel::setBleu(int bleu) {
	bleu = (bleu < 255) ? bleu : 255;
	bleu = (bleu > 0) ? bleu : 0;
	bleu_ = (uint8_t)bleu;
}

uint8_t Pixel::getRouge() const
{
	return rouge_;
}

uint8_t Pixel::getVert() const
{
	return vert_;
}

uint8_t Pixel::getBleu() const
{
	return bleu_;
}

std::ostream& operator<< (std::ostream& os, Pixel pixel) {
	os << "#" << std::hex << std::uppercase << std::setw(2) << std::setfill('0') << static_cast<int>(pixel.getRouge()) << ' '
		<< std::setw(2) << std::setfill('0') << static_cast<int>(pixel.getVert()) << ' '
		<< std::setw(2) << std::setfill('0') << static_cast<int>(pixel.getBleu());
	return os;
}

std::istream& operator>> (std::istream& is, Pixel& pixel) {
	int rouge;
	int vert;
	int bleu;
	is >> rouge >> vert >> bleu;
	pixel.setRouge(rouge);
	pixel.setVert(vert);
	pixel.setBleu(bleu);
	return is;
}