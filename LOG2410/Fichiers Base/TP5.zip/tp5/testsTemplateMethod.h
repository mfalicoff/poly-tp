#ifndef TESTSCOMPOSITE_H
#define TESTSCOMPOSITE_H

#include <algorithm>

#include "Arrosage/ArrosoirOscillant.h"
#include "Arrosage/ArrosoirRotatif.h"

using namespace std;

bool testArrosoirOscillant();

bool testArrosoirRotatif();

#endif
