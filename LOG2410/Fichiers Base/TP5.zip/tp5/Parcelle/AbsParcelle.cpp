/****************************************************************************
**
** Classe AbsParcelle
** Author: Fabrice Charbonneau
** Date: oct-2020
**
****************************************************************************/

#include "AbsParcelle.h"

AbsParcelle::AbsParcelle() {
}

AbsParcelle::~AbsParcelle() {
}

int AbsParcelle::getLongueurTuyeauterie() {
    return m_longueurTuyeauterie;
}
