/*
 * Titre : PivoterMatrice.h - Travail Pratique #4 - Programmation Orient�e Objet
 * Date : 27 F�vrier 2020
 * Auteur : Nabil Dabouz
*/

#ifndef PIVOTER_MATRICE_H
#define PIVOTER_MATRICE_H

#include "def.h"

template<class M>
class PivoterMatrice {
public:
	PivoterMatrice();
	PivoterMatrice(M* matrice);
	Coordonnees changerCoordonneesCentreMatrice(Coordonnees coords);
	Coordonnees recupererCoordonnees(Coordonnees coords);
	void pivoterMatrice(Direction direction);

private:
	M* matrice_;
};

#endif

template<class M>
inline PivoterMatrice<M>::PivoterMatrice():
	matrice_(new M())
{
}

template<class M>
inline PivoterMatrice<M>::PivoterMatrice(M* matrice):
	matrice_(matrice)
{
}

template<class M>
inline Coordonnees PivoterMatrice<M>::changerCoordonneesCentreMatrice(Coordonnees coords)
{
	return {
		coords.x - static_cast<int>(matrice_->getWidth()) / 2,
		coords.y - static_cast<int>(matrice_->getHeight()) / 2
	};
}

template<class M>
inline Coordonnees PivoterMatrice<M>::recupererCoordonnees(Coordonnees coords)
{
	return {
		coords.x + static_cast<int>(matrice_->getWidth()) / 2,
		coords.y + static_cast<int>(matrice_->getHeight()) / 2,
	};
}

template<class M>
inline void PivoterMatrice<M>::pivoterMatrice(Direction direction)
{
	std::unique_ptr<M> matriceTemp = matrice_->clone();
	size_t hauteur = matrice_->getHeight();
	size_t largeur = matrice_->getWidth();
	for (size_t i = 0; i < hauteur; i++) {
		for (size_t j = 0; j < largeur; j++) {
			Coordonnees nouveauxCoords = changerCoordonneesCentreMatrice({ static_cast<int>(j), static_cast<int>(i) });
			Coordonnees coords = { 0, 0 };
			switch (direction) {
			case Direction::Left:
				coords = recupererCoordonnees({ -nouveauxCoords.y, nouveauxCoords.x });
				break;
			case Direction::Right:
				coords = recupererCoordonnees({ nouveauxCoords.y, -nouveauxCoords.x });
				break;
			}
			matrice_->ajouterElement(matriceTemp->operator()(coords.y, coords.x), i, j);
		}
	}
}
