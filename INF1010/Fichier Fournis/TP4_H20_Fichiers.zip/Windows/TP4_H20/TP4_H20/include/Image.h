/*
 * Titre : Image.h - Travail Pratique #4 - Programmation Orient�e Objet
 * Date : 27 F�vrier 2020
 * Auteur : Nabil Dabouz
*/

#ifndef IMAGE_H
#define IMAGE_H

#include <iostream>
#include "AgrandirMatrice.h"
#include "PivoterMatrice.h"

template<typename M>
class Image
{
public:
	Image(std::unique_ptr<M> matrice);
	M* getMatrice();
	void redimensionnerImage(const unsigned int& rapport);
	void pivoterMatrice(Direction direction);
private:
	AgrandirMatrice<M> agrandissement_;
	PivoterMatrice<M> pivotement_;
	std::unique_ptr<M> matrice_;
};

template<typename M>
Image<M>::Image(std::unique_ptr<M> matrice):
	matrice_(std::move(matrice)), agrandissement_(matrice.get()), pivotement_(matrice.get())
{
}

template<typename M>
M* Image<M>::getMatrice()
{
	return matrice_.get();
}

template<typename M>
void Image<M>::redimensionnerImage(const unsigned int& rapport)
{
	agrandissement_.redimensionnerImage(rapport);
}

template<typename M>
inline void Image<M>::pivoterMatrice(Direction direction)
{
	pivotement_.pivoterMatrice(direction);
}

template<typename M>
std::ostream& operator<< (std::ostream& os, Image<M>* image) {
	for (unsigned int i = 0; i < image->getMatrice()->getHeight(); i++) {
		for (unsigned int j = 0; j < image->getMatrice()->getWidth(); j++)
			if (j < image->getMatrice()->getWidth() - 1)
				os << image->getMatrice()->operator()(i, j) << " | ";
			else
				os << image->getMatrice()->operator()(i, j) << " |";
		os << std::endl;
	}
	return os;
}

#endif