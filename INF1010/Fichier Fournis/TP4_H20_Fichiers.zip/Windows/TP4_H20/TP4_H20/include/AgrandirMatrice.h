/*
 * Titre : AgrandirMatrice.h - Travail Pratique #4 - Programmation Orient�e Objet
 * Date : 27 F�vrier 2020
 * Auteur : Nabil Dabouz
*/

#ifndef AGRANDIR_MATRICE_H
#define AGRANDIR_MATRICE_H

#include "def.h"

template<class M>
class AgrandirMatrice
{
public:
	AgrandirMatrice();
	AgrandirMatrice(M* matrice);
	~AgrandirMatrice() = default;
	Coordonnees trouverLePlusProcheVoisin(const unsigned int& rapport, size_t posY, size_t posX);
	void redimensionnerImage(const unsigned int& rapport);

private:
	M* matrice_;
};

#endif

template<class M>
AgrandirMatrice<M>::AgrandirMatrice():
	matrice_(new M())
{
}

template<class M>
AgrandirMatrice<M>::AgrandirMatrice(M* matrice) :
	matrice_(matrice)
{
}

template<class M>
Coordonnees AgrandirMatrice<M>::trouverLePlusProcheVoisin(const unsigned int& rapport, size_t posY, size_t posX)
{
	return { (int)(posX / rapport), (int)(posY / rapport) };
}

template<class M>
void AgrandirMatrice<M>::redimensionnerImage(const unsigned int& rapport)
{
	std::unique_ptr<M> matriceTemp = matrice_->clone();
	matrice_->setHeight(matrice_->getHeight() * rapport);
	matrice_->setWidth(matrice_->getWidth() * rapport);
	size_t hauteur = matrice_->getHeight();
	size_t largeur = matrice_->getWidth();
	for (size_t i = 0; i < hauteur; i++) {
		for (size_t j = 0; j < largeur; j++) {
			Coordonnees procheVoisin = trouverLePlusProcheVoisin(rapport, i, j);
			matrice_->ajouterElement(matriceTemp->operator()(procheVoisin.y, procheVoisin.x), i, j);
		}
	}
}
