#include <stdio.h>
//...

// fonction exécutée par les producteurs
void* producteur( void* pid) {
 
 // ...
   return NULL;             
}
// fonction exécutée par les consommateurs
void* consommateur(void *cid) {
   // ...
    
  return NULL;   
  
}
// ...

// fonction main
int main(int argc, char* argv[]) {
   /* Les paramètres du programme sont, dans l’ordre :
      le nombre de producteurs, le nombre de consommateurs
      et la taille du tampon.*/
    
  // ..
    return 0;
}
