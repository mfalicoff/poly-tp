#ifndef TESTSHELPER_H
#define TESTSHELPER_H

#include <iostream>
using namespace std;

void afficherTestResultat(string nomTest, bool estReussi);

#endif