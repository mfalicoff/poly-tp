package tp1;

public class Square extends Rectangle {
    public Square(Double size) {
        super(size, size);
    }
}
