/****************************************************************************
**
** Classe ArrosoirFixe
** Author: Fabrice Charbonneau
** Date: oct-2020
**
****************************************************************************/

#include "ArrosoirFixe.h"

ArrosoirFixe::ArrosoirFixe()
{}

int ArrosoirFixe::arroser(int debit) {
    // Déjà implémenté, en guise d'exemple
    return debit;
}
