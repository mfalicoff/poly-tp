// To do

// To do
Episode::Episode()
// To do
{
}

// To do
Episode::Episode(unsigned int numEpisode, const std::string& nom, const std::string& duree)
// To do
{
}

// To do
bool Episode::operator==(unsigned int numEpisode)
{
    // To do
}

// To do
std::ostream& operator<<(std::ostream& os, const Episode& episode)
{
    // To do
}

// To do
std::istream& operator>>(std::istream& is, Episode& episode)
{
    // To do
}

// To do
unsigned int Episode::getNumEpisode() const
{
    // To do
}