#include "testsComposite.h"
#include "testsDecorateur.h"
#include "testHelper.h"

using namespace std;

void testSuiteComposite();

void testSuiteDecorateur();
