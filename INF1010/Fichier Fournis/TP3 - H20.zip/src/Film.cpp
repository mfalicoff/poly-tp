// To do

// To do
Film::Film(Auteur* auteur)
// To do
{
}

// To do
Film::Film(const std::string& nom, unsigned int anneeDeSortie, Genre genre, Pays pays,
           bool estRestreintParAge, Auteur* auteur, const std::string& duree)
    // To do
{
}

// To do
std::ostream& Film::afficher(std::ostream& os) const
{
    // To do
}

// To do
std::istream& Film::lire(std::istream& is)
{
    // To do
}

// To do
std::unique_ptr<Media> Film::clone() const
{
    // To do
}
