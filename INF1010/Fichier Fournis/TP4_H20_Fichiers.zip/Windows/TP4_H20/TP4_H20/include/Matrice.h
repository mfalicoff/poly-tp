/*
 * Titre : Matrice.h - Travail Pratique #4 - Programmation Orient�e Objet
 * Date : 27 F�vrier 2020
 * Auteur : Nabil Dabouz
*/

#ifndef MATRICE_H
#define MATRICE_H

#include <memory>
#include <fstream>
#include <sstream>
#include <iostream>

template<typename T>
class Matrice
{

public: 
	Matrice();
	T operator()(const size_t& posY, const size_t& posX);
	bool chargerDepuisFichier(const std::string& nomFichier);
	bool lireElement(const std::string& elementFichier, const size_t& posY, const size_t& posX);
	bool ajouterElement(T element, const size_t& posY, const size_t& posX);
	std::unique_ptr<Matrice<T>> clone();
	void setHeight(size_t height);
	void setWidth(size_t width);
	size_t getHeight();
	size_t getWidth();

private:
	std::vector<std::vector<T>> elements_;
	size_t height_;
	size_t width_;
};

namespace {
	static constexpr int CAPACITE_MATRICE = 100;
}


template<typename T>
Matrice<T>::Matrice() :
	height_(0),
	width_(0)
{
	std::vector<T> colonne(CAPACITE_MATRICE);
	elements_ = std::vector<std::vector<T>>(CAPACITE_MATRICE, colonne);
}

/**
 * @brief retourne l'element dans la ligne posY et la colonne posX
 * @param posY, la ligne dans la matrice
 * @param posX, la colonne dans la matrice
 * @return element de type T
*/
template<typename T>
T Matrice<T>::operator()(const size_t& posY, const size_t& posX) {
	if (posY < CAPACITE_MATRICE && posX < CAPACITE_MATRICE)
		return elements_[posY][posX];
	else
		return T();
}

/**
 * @brief charger la matrice � partir du fichier pass� en param�tre
 * @param nomFichier, le nom du fichier
 * @return true si la lecture est r�ussie
*/
template<typename T>
bool Matrice<T>::chargerDepuisFichier(const std::string& nomFichier)
{
	std::ifstream fichier(nomFichier);
	if (fichier) {
		size_t widthMax = 0;
		height_ = 0;
		width_ = 0;
		std::string ligne;
		while (std::getline(fichier, ligne)) {
			if (ligne == "L") {
				height_++;
				width_ = 0;
			}
			else {
				width_++;
				lireElement(ligne, height_ - 1, width_ - 1);
				widthMax = (width_ < widthMax) ? widthMax : width_;
			}
		}
		width_ = widthMax;
		return true;
	}
	std::cerr << "Le fichier " << nomFichier
		<< " n'existe pas. Assurez vous de le mettre au bon endroit.\n";
	return false;
}

/**
 * @brief lire un element et l'ajouter dans la matrice
 * @param elementFichier, une chaine de caracs qui contient les informations de l'element � ajouter
 * @param posY, la ligne dans la matrice
 * @param posX, la colonne dans la matrice
 * @return true si la lecture est r�ussie
*/
template<typename T>
bool Matrice<T>::lireElement(const std::string& elementFichier, const size_t& posY, const size_t& posX)
{
	T element;
	std::istringstream stream(elementFichier);
	if (stream >> element)
		return ajouterElement(element, posY, posX);
	return false;
}

/**
 * @brief ajouter un element dans la matrice
 * @param posY, la ligne dans la matrice
 * @param posX, la colonne dans la matrice
 * @return true si l'�criture s'est bien faite
*/
template<typename T>
bool Matrice<T>::ajouterElement(T element, const size_t& posY, const size_t& posX)
{
	if (posX < width_ && posY < height_) {
		elements_[posY][posX] = element;
		return true;
	}
	return false;
}

/**
 * @brief faire une copie de la matrice
 * @return pointeur vers la nouvelle matrice
*/
template<typename T>
std::unique_ptr<Matrice<T>> Matrice<T>::clone()
{
	std::unique_ptr<Matrice<T>> matrice(new Matrice<T>);
	matrice->setHeight(height_);
	matrice->setWidth(width_);
	for (size_t i = 0; i < height_; i++) {
		for (size_t j = 0; j < width_; j++) {
			matrice->ajouterElement(this->operator()(i, j), i, j);
		}
	}
	return matrice;
}
/**
 * @brief set la hauteur de la matrice
 * @param posY, la ligne dans la matrice
 * @param posX, la colonne dans la matrice
 * @return true si l'�criture s'est bien faite
*/
template<typename T>
void Matrice<T>::setHeight(size_t height)
{
	height_ = (height > CAPACITE_MATRICE) ? height_ : height;
}

template<typename T>
void Matrice<T>::setWidth(size_t width)
{
	width_ = (width > CAPACITE_MATRICE) ? width_ : width;
}

template<typename T>
size_t Matrice<T>::getHeight()
{
	return height_;
}

template<typename T>
size_t Matrice<T>::getWidth()
{
	return width_;
}

#endif

