#include "testsFactoryMethod.h"
#include "testsTemplateMethod.h"
#include "testHelper.h"


void testSuiteFactoryMethod();

void testSuiteTemplateMethod();
